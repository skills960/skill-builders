
const startServer = require('./src/_app');
startServer();